import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text('Ai Story Gen'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(
              Icons.flutter_dash,
              size: 100,
              color: Theme.of(context).primaryColor,
            ),
            SizedBox(height: 20),
            Text(
              'Welcome to Ai Story Gen!',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            SizedBox(height: 10),
            Padding(
              padding: EdgeInsets.all(16.0),
              child: Text(
                'You are a senior Flutter developer and project generator. Generate a complete, ready-to-run Flutter project (Android) named "Ai Story Gen". Produce production-quality, well-structured code with comments, following modern Flutter best practices and null-safety.

--- Project details ---
App name: Ai Story Gen
Platform: Android (Flutter)
Flutter version: latest stable (null-safety)
State management: Riverpod (use flutter_riverpod)
Architecture: Feature-driven architecture with clear separation: `lib/main.dart`, `lib/core` (for shared utilities, constants, themes), `lib/models`, `lib/features/{feature_name}/screens`, `lib/features/{feature_name}/widgets`, `lib/features/{feature_name}/services`, `lib/features/{feature_name}/providers`, `assets/`, `i18n/`. Adhere to clean architecture principles where appropriate, separating presentation, domain, and data layers within features. Use `freezed` or `json_serializable` for data models to ensure immutability and efficient serialization/deserialization.

--- Functional requirements ---
1.  **Splash screen:**
    *   **UI/UX:** A visually appealing screen featuring a prominent, center-aligned animated SVG logo (e.g., a stylized quill pen writing or a book opening). The animation should be subtle and smooth, perhaps a `FadeTransition` or `ScaleTransition`. The background color should be a solid primary brand color from the chosen color scheme.
    *   **Navigation Flow:** Auto-navigate after a 2-second delay. The app should check if it's the first launch (via `shared_preferences`) to decide between `OnboardingScreen` or `AuthScreen` (if not logged in) / `HomeScreen` (if logged in, checking `FirebaseAuth.instance.currentUser`).
    *   **Technical:** Utilize `flutter_svg` for the logo. Logic to manage navigation based on user's first-time status and authentication state.

2.  **Onboarding:**
    *   **UI/UX:** A `PageView` displaying 2-3 engaging slides. Each slide will feature a high-quality vector illustration (SVG, `flutter_svg`), a bold, concise title, and a brief descriptive paragraph. A `dots_indicator` will provide visual feedback on the current slide position. A "Skip" `TextButton` should be present in the top-right corner, and a primary "Get Started" `ElevatedButton` at the bottom of the last slide.
    *   **Data Model:** Onboarding content (image asset path, localized title, localized description) should be defined in a `List<OnboardingPageModel>`.
    *   **Navigation Flow:** "Skip" button navigates directly to `AuthScreen`. "Get Started" button navigates to `AuthScreen`.
    *   **User Interactions:** Smooth horizontal swiping for navigation between slides. Tapping the "Skip" or "Get Started" button should mark onboarding as seen in `shared_preferences`.

3.  **Authentication (Login/Signup/Password Reset):**
    *   **UI/UX:**
        *   **Login/Signup:** Two distinct screens with `TextFormField`s for Email and Password. Password fields should have a toggleable visibility icon. Clear `InputDecoration`s with labels, hints, and inline error messages for validation feedback. Prominent `ElevatedButton`s for "Login" / "Sign Up". A dedicated custom `ElevatedButton` with the Google logo and brand styling for "Sign in with Google". A "Forgot Password?" `TextButton` link. During authentication, a `CircularProgressIndicator` should be displayed within the active button.
        *   **Password Reset:** A separate screen with a single `TextFormField` for the user's email. A "Send Reset Link" `ElevatedButton`. Provide clear `SnackBar` messages for success or failure.
    *   **Navigation Flow:** Upon successful login/signup, navigate to `HomeScreen` using `Navigator.pushAndRemoveUntil` to clear the navigation stack. After sending a password reset link, return to the login screen with a success message.
    *   **User Interactions:** Real-time validation for email format and password strength (e.g., min length). Google Sign-In should leverage the system browser for a seamless experience.

4.  **Home screen:**
    *   **UI/UX:** `Scaffold` with a `Drawer` (leading `IconButton(Icons.menu)` in `AppBar`) for navigation to `Settings`, `Saved Stories`, and `Logout`. The `AppBar` title should be "Ai Story Gen".
        *   **Welcome Message:** A personalized `Text` widget, e.g., "Welcome, [Username]!" or "Hello, Storyteller!", conditionally displayed based on user login status.
        *   **"Generate Story" CTA:** A large, visually distinct `ElevatedButton` (e.g., primary color with an `Icons.bolt` or `Icons.auto_awesome` icon) or a `Card` widget with `GestureDetector` for a richer, more engaging call to action.
        *   **Recommended Stories:** A horizontal `ListView.builder` displaying `Card` widgets. Each card will feature a genre-specific icon/placeholder image, a story title, and a brief 1-2 sentence summary. Tapping a card navigates to `StoryDetailsScreen`.
        *   **Saved Stories (Favorites):** A vertical `ListView.builder` (or `Column` of `ListTile`s if limited number) displaying `ListTile` or `Card` widgets. Each item should show the story title, genre, and creation date. Implement `Dismissible` for swipe-to-delete with an "Undo" `SnackBar` action. Tapping an item navigates to `StoryDetailsScreen`.
    *   **Data Model:** `StoryModel` (from `lib/models/story.dart`) will represent both recommended and saved stories.
    *   **Functionality:** Use Riverpod `StreamProvider` or `FutureProvider` to fetch recommended stories (mock AI-generated) and saved stories from Firestore. Implement local caching for saved stories for immediate display.

5.  **Story generation screen:**
    *   **UI/UX:**
        *   **Input Forms:** A `TextFormField` for a single-line story title input, and a `TextFormField` with `maxLines: null` (expanding) for the multi-line story prompt. Include clear hint texts.
        *   **Genre Selection:** A `DropdownButtonFormField` populated with predefined genres (Fantasy, Sci-Fi, Romance, Horror, Comedy, Adventure).
        *   **Length Selector:** A `SegmentedButton` or `ToggleButtons` widget for "Short" (100-300 words), "Medium" (300-700 words), "Long" (700-1200 words).
        *   **"Generate Story" Button:** A primary `ElevatedButton`. It should be disabled during the story generation process.
        *   **Loading Indicator:** While generating, display a `CircularProgressIndicator` centered over the generated story area or a custom `Lottie` animation (if `lottie` package is included).
        *   **Generated Story Display:** Once generated, display the story within a `Card` or `Container` with adequate padding. The title should be a large, bold `Text` widget, followed by a smaller, muted `Text` for the genre/length subtitle. The story body should be a scrollable `SelectableText` (for easy copying) within an `Expanded` widget.
        *   **Action Buttons:** A `Row` of `IconButton`s (e.g., `Icons.bookmark_border` for Save, `Icons.share` for Share, `Icons.copy` for Copy, `Icons.picture_as_pdf` for Export PDF) below the story content.
    *   **Data Models:** `GeneratedStory` model.
    *   **Functionality:**
        *   Form validation to ensure prompt is not empty.
        *   Integration with `lib/services/ai_service.dart`.
        *   Integration with `lib/features/auth/services/auth_service.dart` to get the current user ID for saving.
        *   Integration with `lib/services/storage_service.dart` for saving stories to Firestore.
        *   `share_plus` for text/image sharing, `screenshot` for image snapshots, `pdf` and `printing` for PDF export.

6.  **Story details / reader:**
    *   **UI/UX:** `Scaffold` with an `AppBar` containing a back button, the story title, and action `IconButton`s for "Share" (`Icons.share`) and "Options" (`Icons.more_vert`). The main content area should be a `SingleChildScrollView` displaying the full story body (`SelectableText`). A persistent bottom sheet or a `PopupMenuButton` from the AppBar "Options" icon should provide controls for:
        *   **Font Size Adjustment:** A `Slider` to increase/decrease font size with a current value display.
        *   **Line Height Adjustment:** A `Slider` for line spacing.
        *   **Theme Toggle:** `IconButton` (`Icons.brightness_4` / `Icons.brightness_7`) to switch between Light/Dark themes, with the preference persisted.
        *   **Bookmark/Unbookmark:** `IconButton(Icons.bookmark)` / `IconButton(Icons.bookmark_border)` that updates the saved status in Firestore.
        *   **Delete Story:** `IconButton(Icons.delete_outline)`.
    *   **Functionality:**
        *   Font size and line height preferences should be persisted using `shared_preferences` and applied dynamically using `TextStyle`.
        *   Theme preference should be persisted and update the app's `ThemeMode`.
        *   Bookmark status updates `Firestore` and local cache.
        *   Delete action removes the story from `Firestore` and local cache with a confirmation dialog.

7.  **Saved stories:**
    *   **UI/UX:** `Scaffold` with an `AppBar` containing the title "Saved Stories," an `IconButton(Icons.search)` to activate search, and an `IconButton(Icons.filter_list)` for genre filtering. Below the AppBar, a `ListView.separated` displays story `ListTile` or `Card` widgets, each showing title, genre, a short summary (if available), and creation date.
        *   **Search:** Tapping the search icon should expand a `SearchBar` or `TextFormField` within the AppBar for live text input filtering.
        *   **Genre Filter:** Tapping the filter icon should open a `BottomSheet` or `Drawer` with `FilterChip` or `ChoiceChip` widgets for genre selection, allowing multi-selection or single-selection.
        *   **Swipe-to-Delete:** Each list item should be wrapped in a `Dismissible` widget, allowing swipe-to-delete with a confirmation background. A `SnackBar` with an "Undo" action should appear after a story is dismissed.
    *   **Data Model:** `StoryModel`.
    *   **Functionality:**
        *   Riverpod `StreamProvider` to fetch saved stories from Firestore, ordered by creation date (newest first).
        *   Implement a robust local caching strategy (prefer `Hive` for structured data over `shared_preferences` here) for offline reading. Display cached data immediately, then update from Firestore.
        *   Search logic should filter the displayed list dynamically based on story title or keywords.
        *   Filter logic should update the displayed list based on selected genres.
        *   `Firestore.runTransaction` for atomic and robust delete operations.

8.  **Settings:**
    *   **UI/UX:** `Scaffold` with an `AppBar` and a `ListView` of `ListTile` widgets for each setting.
        *   **Theme:** `ListTile` with a `DropdownButton` or a `RadioListTile` for "System Default", "Light", "Dark" theme selection.
        *   **Font Size:** `ListTile` containing a `Slider` to adjust the default reading font size, with a `Text` widget displaying the current value.
        *   **Language Selection:** `ListTile` with a `DropdownButton` for "English", "العربية" (Arabic).
        *   **About:** `ListTile` navigating to an "About" screen (simple `Scaffold` with app name, icon, short description).
        *   **Contact Us:** `ListTile` with an `IconButton(Icons.email)` that opens the user's default email client pre-populated with the app's support email address.
        *   **App Version:** `ListTile` displaying the current app version (e.g., "Version 1.0.0").
    *   **Functionality:**
        *   Persist theme, font size, and language preferences using `shared_preferences`.
        *   Theme changes should immediately update the entire app's `ThemeMode`.
        *   Font size changes should immediately update the default `TextTheme` used throughout the app, especially in the `StoryDetailsScreen`.
        *   Language selection should update `Locale` and trigger a rebuild for localization.
        *   Use `url_launcher` for the contact email link.
        *   Use `package_info_plus` (add to `pubspec.yaml`) to retrieve the app version dynamically.
        *   Ensure all layouts and text directions correctly handle RTL for Arabic (`Directionality` widget and `start`/`end` properties for margins/paddings).

9.  **Notifications:**
    *   **Technical:** Utilize `flutter_local_notifications` to schedule a daily "Story of the Day" local notification at a specific time (e.g., 9 AM local time).
    *   **Content:** Notification title: "Story of the Day!", body: "Discover a new adventure generated just for you!", payload: a `storyId` from the recommended stories list.
    *   **User Interaction:** Tapping the notification should open the app and navigate directly to the `StoryDetailsScreen` for the corresponding `storyId`.
    *   **Workflow:** User grants notification permission during onboarding or first launch. Notification is scheduled once and then daily thereafter.

10. **Backend & storage:**
    *   **Firebase Integration:** `firebase_core`, `firebase_auth`, `cloud_firestore`, `firebase_storage`.
        *   **Authentication:** Firebase Auth for email/password and Google Sign-In.
        *   **Firestore:** Used for storing `Story` models (saved by users) in a `users/{userId}/saved_stories` collection, and a `users/{userId}/ai_history` collection for AI generation logs.
        *   **Firebase Storage:** Placeholder for potential future image uploads (e.g., custom story covers).
    *   **Local Caching:** Utilize `shared_preferences` for user preferences (theme, font size, language, onboarding status) and `hive` (preferable for structured data) for robust local caching of `Story` models for offline reading of saved stories. Implement a `Repository` layer that first attempts to fetch data from the local cache, falling back to Firestore, and then updating the cache.
    *   **Configuration:** Provide clear placeholder instructions within `README.md` on how to set up Firebase and where to place `google-services.json`. Include an example `firebase_options.dart` with placeholder values (no real credentials).
    *   **Fallback:** The app should gracefully handle cases where Firebase configuration is not present, falling back to a local-only mode with a clear user message.

11. **Extra features:**
    *   **Export Story to PDF:** Integrate `pdf` and `printing` packages. Provide an `IconButton` (e.g., `Icons.picture_as_pdf`) on `StoryGenerationScreen` (for newly generated stories) and `StoryDetailsScreen` (for saved stories). The PDF should include the story title, genre, and full content, formatted cleanly with pagination. Save the PDF to a user-accessible directory (using `path_provider`).
    *   **Share Story:** Integrate `share_plus` package.
        *   **Share as Text:** An `IconButton` (`Icons.share`) to share the story title and full content as plain text.
        *   **Share as Image Snapshot:** Integrate `screenshot` package. An `IconButton` (`Icons.image`) to capture a screenshot of the displayed story content (within a `RepaintBoundary`) and share it as an image file.
    *   **AI History Log:** Store a log of each AI story generation request in Firestore under `users/{userId}/ai_history`. Each log entry should include `prompt`, `genre`, `length`, `generatedStoryId`, and `timestamp`. This data can be used for future analytics or personalized recommendations. Provide local fallback (e.g., Hive) if Firestore is unavailable.

12. **Accessibility & responsiveness:**
    *   **Responsive Layout:** Design layouts to adapt seamlessly across various Android device sizes and orientations using `MediaQuery`, `Expanded`, `Flexible`, `LayoutBuilder`, and `FittedBox` widgets. Consider `Breakpoints` for major layout changes.
    *   **Readable Fonts:** Use system-default fonts or highly legible typefaces (e.g., Roboto). Ensure `TextTheme` is defined in `ThemeData` to support varying font sizes and weights.
    *   **Accessible Contrast:** Adhere to WCAG guidelines for color contrast (e.g., a minimum contrast ratio of 4.5:1 for normal text). Define a robust `ColorScheme` within `ThemeData` that ensures good contrast between text and background across both light and dark themes.

13. **Tests:**
    *   **Widget Test:** Include at least one comprehensive widget test for `StoryGenerationScreen`, covering input field interactions, genre/length selection, button states (enabled/disabled, loading), and the display of a generated story. Mock `AiService` and `AuthService` dependencies.
    *   **Unit Test:** Include at least one unit test for the `MockAiService`, verifying the structure of the `GeneratedStory` model, the simulated network delay, and its deterministic behavior when a seed is provided.

--- Implementation requirements / packages to include ---
Please scaffold `pubspec.yaml` with these packages (or latest stable equivalents):
-   `flutter_riverpod`
-   `firebase_core`, `firebase_auth`, `cloud_firestore`, `firebase_storage`
-   `google_sign_in`
-   `shared_preferences`
-   `hive`, `hive_flutter` (for local story caching)
-   `flutter_local_notifications`
-   `intl`, `flutter_localizations`
-   `path_provider`
-   `pdf`
-   `printing` (often used with `pdf` for saving/sharing)
-   `share_plus`
-   `screenshot` (for share as image)
-   `flutter_svg` (for vector assets like logo, onboarding images)
-   `uuid` (for generating unique IDs)
-   `lottie` (optional, for splash/loading animations if desired)
-   `dots_indicator` (for onboarding `PageView`)
-   `package_info_plus` (for app version in settings)
-   `url_launcher` (for contact email)
-   `freezed_annotation`, `build_runner`, `freezed` (for immutable data models)
-   `json_annotation`, `json_serializable` (for Firestore model serialization)

--- AI integration (mock) ---
Create a service `lib/features/ai_generation/services/ai_service.dart` with:
-   A function `Future<GeneratedStory> generateStory({required String title, required String prompt, required String genre, required StoryLength length})`.
-   **Implementation:** Simulate a network delay of 1.5–3 seconds using `Future.delayed`. Then, return a `GeneratedStory` model with the following structure:
    ```dart
    // In lib/models/generated_story.dart (using freezed for immutability)
    @freezed
    class GeneratedStory with _$GeneratedStory {
      const factory GeneratedStory({
        required String id,
        required String title,
        required String genre,
        required StoryLength length,
        required String content,
        required DateTime createdAt,
        required String summary, // 2-3 sentence summary
        @Default(false) bool isSaved,
      }) = _GeneratedStory;

      factory GeneratedStory.fromJson(Map<String, dynamic> json) => _$GeneratedStoryFromJson(json);
    }
    // In lib/models/story_length.dart
    enum StoryLength { short, medium, long }
    ```
-   Make the mock deterministic for testing by seeding the `Random` number generator. Use lorem ipsum generators or similar for realistic-looking `title`, `content`, and `summary` based on the requested `length`. Provide clear instructions on how to swap this mock service with a real API call later.

--- Code quality & documentation ---
-   Provide clear, concise inline comments for each major file, class, method, and complex logic block, explaining *why* certain design decisions were made, not just *what* the code does.
-   `README.md` with:
    -   A comprehensive project overview and its core features.
    -   Detailed "How to Run" instructions: `flutter pub get`, Android build steps, and explicit instructions for Firebase setup (where to add `google-services.json` and how to configure `firebase_options.dart`).
    -   Clear guidance on how to swap the mock AI service with a real AI API (e.g., using dependency injection or `faker.dart`).
    -   Information on the chosen architecture and state management.
-   `analysis_options.yaml` enabling a robust set of recommended lints for code quality and consistency.

--- Assets & icons ---
-   Generate adaptive app icons (PNG sizes for various densities) and place them in `android/app/src/main/res/mipmap-` folders.
-   Include a placeholder app logo (SVG or high-resolution PNG) in `assets/images/logo.svg` or `assets/images/logo.png`.
-   Ensure the `assets/` folder is configured in `pubspec.yaml`.

--- Localization ---
-   Provide full internationalization for English (`en`) and Arabic (`ar`) using `.arb` files and the `flutter_gen_l10n` tool.
-   Implement correct wiring for `flutter_localizations` in `main.dart`.
-   Crucially, ensure full RTL (Right-to-Left) layout support for Arabic, meaning:
    -   Text direction should be correctly handled (`TextDirection.rtl`).
    -   Layout elements (e.g., `Row`, `ListTile` leading/trailing icons) should mirror horizontally.
    -   `padding` and `margin` should use `start`/`end` properties instead of `left`/`right` for consistent layout mirroring.

--- Output expected from generator ---
1.  A complete Flutter project tree (zipped) or individual files with code content, ready for compilation.
2.  `main.dart` fully configured with Riverpod `ProviderScope`, Firebase initialization (with comment placeholders for actual credentials), routing setup using `go_router` or `Navigator 2.0` (preferred), `ThemeData` (light/dark/system themes), and localization delegates.
3.  All primary screen files: `Splash`, `Onboarding`, `Auth` (Login/Signup/Password Reset), `Home`, `GenerateStory`, `StoryDetails`, `SavedStories`, `Settings`.
4.  Service files: `ai_service.dart`, `auth_service.dart`, `story_repository.dart` (for Firestore/Hive interaction), `notification_service.dart`.
5.  Riverpod provider files for state management across features.
6.  A comprehensive `README.md` as detailed above.

--- Final note to the generator ---
Generate code that is compile-ready (aside from inserting actual Firebase credentials). Keep everything modular and comment clearly where the developer must add real API keys or configuration files. Use modern UI patterns, smooth animations, and clear error handling. Ensure core navigation and functional flows are fully operational with the mock AI service and local storage.',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyLarge,
              ),
            ),
            SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                // Navigate to next screen
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Feature coming soon!')),
                );
              },
              child: Text('Get Started'),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Add functionality here
        },
        tooltip: 'Action',
        child: Icon(Icons.add),
      ),
    );
  }
}