# Ai Story Gen

You are an expert app designer. Enhance the user's app description to include specific technical details, UI/UX requirements, and feature specifications that will help generate a better Flutter app.

Add details about:
- Specific screens and navigation flow
- UI components and layouts
- Color schemes and design style
- Data models and functionality
- User interactions and workflows

Original prompt: You are a senior Flutter developer and project generator. Generate a complete, ready-to-run Flutter project (Android) named "Ai Story Gen". Produce production-quality, well-structured code with comments, following modern Flutter best practices and null-safety.

--- Project details ---
App name: Ai Story Gen
Platform: Android (Flutter)
Flutter version: latest stable (null-safety)
State management: Riverpod (use flutter_riverpod)
Architecture: feature folders with clear separation: lib/main.dart, lib/models, lib/screens, lib/widgets, lib/services, lib/providers, lib/utils, assets/, i18n/
    * `lib/main.dart`: Entry point, responsible for app initialization (Firebase, Riverpod scopes, routing).
    * `lib/models`: Contains immutable data structures (`freezed` or `equatable`) for all entities (e.g., `User`, `Story`, `GeneratedStory`).
    * `lib/screens`: Top-level UI components representing distinct pages/views.
    * `lib/widgets`: Reusable UI components (e.g., `StoryCard`, `AuthForm`).
    * `lib/services`: Encapsulates business logic, API calls (Firebase Auth/Firestore, AI), and local storage interactions.
    * `lib/providers`: Riverpod-specific files defining `Provider`s, `StateNotifierProvider`s, `StreamProvider`s, etc., for state management.
    * `lib/utils`: Helper functions, constants, theme data, validation logic.
    * `assets/`: Image, font, and other asset files (`assets/images/`, `assets/icons/`, `assets/illustrations/`).
    * `i18n/`: Internationalization files (ARBs).

--- Functional requirements ---
1.  **Splash screen:**
    *   **UI/UX:** Displays a centered app logo (`logo.svg` or `logo.png`) with a subtle scaling and fade-in animation. Below the logo, a tagline "Your imagination, amplified." is displayed. The background should be a solid color or a gradient chosen from the app's primary color palette.
    *   **Navigation Flow:** Automatically navigates after 2 seconds. The destination is determined by the user's authentication status and onboarding completion:
        *   If `hasSeenOnboarding` (from `shared_preferences`) is false, navigate to `OnboardingScreen`.
        *   If a user is logged in (via `firebase_auth`), navigate to `HomeScreen`.
        *   Otherwise (not logged in, onboarding seen), navigate to `AuthScreen`.
    *   **Technical:** Utilize `AnimatedOpacity` or `Hero` for the logo animation. Use `Future.delayed` or `Timer` for the duration. Initial Firebase auth state check via `FirebaseAuth.instance.authStateChanges()`.

2.  **Onboarding:**
    *   **UI/UX:** Consists of 2-3 full-screen slides implemented using a `PageView` with a `dots_indicator` for visual progress. Each slide features a prominent hero illustration/image, a bold `headlineMedium` title, and a concise `bodyLarge` description. A "Skip" text button is placed in the top-right corner. A prominent "Get Started" `ElevatedButton` is at the bottom center of the last slide. Smooth horizontal slide transitions.
    *   **Content:**
        *   Slide 1: Title "Ignite Your Imagination", illustration of a person writing creatively, description about generating unique stories from simple prompts.
        *   Slide 2: Title "Explore Diverse Genres", illustration representing various themes (e.g., fantasy castle, sci-fi spaceship), description about selecting genre and story length.
        *   Slide 3: Title "Save & Share Your Tales", illustration of a library or sharing icon, description about saving favorite stories for offline reading and sharing them with friends.
    *   **Navigation Flow:** "Skip" button navigates directly to `AuthScreen`. "Get Started" button on the last slide navigates to `HomeScreen` if logged in, otherwise to `AuthScreen`.
    *   **Persistence:** A `bool` flag (`hasSeenOnboarding`) is stored in `shared_preferences` upon completing or skipping onboarding to prevent showing it on subsequent app launches.

3.  **Authentication:**
    *   **UI/UX:**
        *   **Login Screen:** Features the app logo/name at the top. Includes `TextFormField` for Email and Password (with toggleable visibility for password). A "Forgot Password?" `TextButton` below the password field. A primary "Login" `ElevatedButton`. A "Don't have an account? Sign Up" `TextButton` link. A subtle "Or" divider before a "Sign in with Google" `ElevatedButton` (with a leading Google logo icon).
        *   **Sign Up Screen:** Similar layout to Login. Adds a `TextFormField` for Name (optional) and a "Confirm Password" `TextFormField`. "Sign Up" `ElevatedButton` and "Already have an account? Login" `TextButton` link.
        *   **Forgot Password Screen:** A `TextFormField` for Email. A "Send Reset Link" `ElevatedButton`. `SnackBar` messages for success/error feedback.
        *   **Validation:** Real-time client-side input validation (e.g., email format, password strength, password matching, non-empty fields) using `Form` and `TextFormField` `validator` properties.
        *   **Loading States:** Display a `CircularProgressIndicator` overlay or disable buttons during authentication network operations.
    *   **Data Model:** `AuthService` (a Riverpod `Provider`) handles all `firebase_auth` and `google_sign_in` operations.
    *   **Error Handling:** Graceful handling of `FirebaseAuthException` with user-friendly `SnackBar` messages.

4.  **Home screen:**
    *   **UI/UX:**
        *   **App Bar:** Displays app logo/name on the left. On the right, a circular `UserAvatar` widget (with user's initial or profile picture) that acts as a profile button, navigating to `SettingsScreen`.
        *   **Welcome Message:** A `Text` widget (e.g., `headlineSmall`) displaying "Welcome back, [UserName]!" if the user is logged in.
        *   **Generate Story CTA:** A large, visually prominent `ElevatedButton` or `Card` with a creative icon (e.g., a magic wand or lightbulb), centered on the screen. It occupies significant vertical space, encouraging story generation. Tapping navigates to `StoryGenerationScreen`.
        *   **Recommended Stories:** A horizontal `ListView.builder` displaying a `StoryCard` widget for each recommended story. Each `StoryCard` shows title, genre, and a placeholder image or a genre-specific icon. Includes a "See All" `TextButton` link to expand the view to a dedicated `RecommendedStoriesScreen` (future feature, currently just a placeholder).
        *   **Saved Stories:** A vertical `ListView.builder` displaying `ListTile` or `StoryListItem` widgets for the user's saved stories. Each item shows title, genre, a snippet of the summary, and icons for "favorite" (filled if saved) and "share". Tapping navigates to `StoryDetailsScreen`. Includes a "See All" `TextButton` link, navigating to `SavedStoriesScreen`.
        *   **Empty States:** Clear `Text` messages and relevant illustrations (e.g., a blank book for no saved stories) for empty lists.
    *   **Data:** Riverpod `StreamProvider`s for user data (`FirebaseAuth` and `Firestore`) and saved stories from Firestore. Recommended stories could be a `FutureProvider` from a `StoryService` (mocked).

5.  **Story generation screen:**
    *   **UI/UX:**
        *   **Input Section:**
            *   `TextFormField` for "Story Title" (single line, max length 50 characters, `InputDecoration` with label and hint).
            *   `TextFormField` for "Prompt" (multi-line, `maxLines: null`, `minLines: 5`, `InputDecoration` with label and hint).
            *   `DropdownButtonFormField` for "Genre" (options: Fantasy, Sci-Fi, Romance, Horror, Comedy, Adventure).
            *   `SegmentedButton` or `ToggleButtons` for "Length" selection (Short, Medium, Long, with tooltips indicating estimated word count range, e.g., Short: 300-500 words).
        *   **Action Button:** A wide, primary-colored "Generate Story" `ElevatedButton` at the bottom of the input section. Disabled until all required fields are filled.
        *   **Loading State:** While generating, a `LinearProgressIndicator` appears at the top of the screen or a `CircularProgressIndicator` overlays the generated story area.
        *   **Generated Story Display:** This section is initially hidden and appears below the generation button after the story is generated. It's a `SingleChildScrollView` containing:
            *   `Text` for the story title (`displaySmall`).
            *   `Text` for subtitle (genre/length, `labelLarge`).
            *   `Text` for the story body (`bodyLarge`, `selectable: true`).
        *   **Action Buttons (Post-Generation):** A `Row` of `IconButton`s with tooltips (Save, Share, Copy, Export PDF) positioned below the generated story. The "Save" icon should dynamically update its state (filled/outlined) based on whether the story is currently saved.
    *   **Data Models:** `GeneratedStory` model (`id`, `title`, `genre`, `length`, `content`, `createdAt`, `summary`).
    *   **Workflow:** User fills inputs -> Clicks "Generate" -> Loading indicator visible -> Mock AI service called -> Story content displayed -> User can choose to save, share, copy, or export.

6.  **Story details / reader:**
    *   **UI/UX:**
        *   **App Bar:** Displays the story title. Action icons on the right: Share, Bookmark/Unbookmark, Delete.
        *   **Story Content:** `SingleChildScrollView` containing the full story text. The primary story text is rendered using `Text` with adjustable `TextStyle` properties (font size, line height). The text should be `selectable`.
        *   **Reading Controls:** A floating action button (FAB) or an `IconButton` in the `AppBar` opens a bottom sheet or modal dialog with reading preferences:
            *   `Slider` for "Font Size" adjustment (e.g., 14-24sp).
            *   `Slider` for "Line Height" adjustment (e.g., 1.0-2.0).
            *   `SegmentedButton` or `Switch` for "Theme" selection (System/Light/Dark).
            *   A placeholder "Read Aloud" button for future speech-to-text integration.
        *   **Persistence:** Font size and line height preferences are saved using `shared_preferences` and apply across all stories.
    *   **Functionality:** `StoryService` for bookmarking/deleting from Firestore. `share_plus` for sharing. Theme changes trigger `ThemeData` update via a Riverpod `StateNotifierProvider`.
    *   **Navigation:** Passed story ID or `Story` object via `GoRouter` or `Navigator.push`.

7.  **Saved stories:**
    *   **UI/UX:**
        *   **App Bar:** "Saved Stories" title. Action icons: Search (opens an inline `TextFormField` search bar in the `AppBar`) and Filter (opens a bottom sheet for genre filtering).
        *   **List Display:** `ListView.builder` displaying `StoryListItem` widgets. Each `StoryListItem` shows the story's title, genre, creation date, and a brief summary snippet.
        *   **Swipe-to-Delete:** Each `StoryListItem` is wrapped in a `Dismissible` widget. Swiping left/right reveals a red background with a trash can icon. Upon dismissal, a `SnackBar` appears with "Story deleted. Undo?" offering a brief window to revert the action.
        *   **Search and Filter:** The search bar filters the list dynamically as the user types. The filter bottom sheet offers `ChoiceChip`s or `Checkbox`es for genres, with "Apply" and "Clear Filter" buttons.
        *   **Empty State:** A `Text` message "No saved stories yet. Generate some!" with a relevant illustration.
    *   **Data:** Riverpod `StreamProvider` for real-time updates of saved stories from Firestore, with local caching using `hive` or `shared_preferences` for offline reading. `StoryService` handles data retrieval, filtering, search, and deletion logic.

8.  **Settings:**
    *   **UI/UX:** Implemented as a `ListView` of `ListTile`s, logically grouped.
        *   **Theme:** `ListTile` titled "App Theme" with a subtitle showing the current theme. A `SegmentedButton` or `RadioListTile`s allow selection between "System", "Light", and "Dark" themes.
        *   **Font Size:** `ListTile` titled "Default Story Font Size" with a `Slider` ranging from 14.0 to 24.0 points. Changes are immediately reflected in a preview text and persisted.
        *   **Language:** `ListTile` titled "Language" with a `DropdownButton` offering "English" and "Arabic". Changing the language triggers an app rebuild to apply localization and RTL layout.
        *   **About:** `ListTile` "About Ai Story Gen" which opens a modal `AboutDialog` or navigates to an `AboutScreen` displaying app information.
        *   **Contact:** `ListTile` "Contact Us" which launches the default email client with a pre-filled recipient address.
        *   **Version:** `ListTile` "App Version" displaying the app's current version number (e.g., "1.0.0 (Build 1)").
    *   **Technical:** `shared_preferences` for persisting theme, font size, and language preferences. Riverpod `StateProvider`s manage these settings globally. `intl` and `flutter_localizations` for i18n. `url_launcher` for email links. `package_info_plus` for app version.
    *   **RTL Support:** `Directionality` widget and `Localizations` are crucial. Ensure all `AppBar` layouts, `Row` children, and `TextFormField`s correctly mirror for `TextDirection.rtl` when Arabic is selected.

9.  **Notifications:**
    *   **UI/UX:** No direct UI within the app for managing notifications, but the notifications themselves should be well-formatted. Title: "Story of the Day", Body: "A new tale awaits you! Discover a fresh story generated just for you." or a snippet from a recommended story.
    *   **Technical:** `NotificationService` (Riverpod `Provider`) handles initializing `flutter_local_notifications` and scheduling a daily notification at a fixed time (e.g., 9 AM). Tapping the notification should open the app to the `HomeScreen` or directly to a `StoryDetailsScreen` if a specific story is linked.

10. **Backend & storage:**
    *   **Firebase Integration:** `firebase_core`, `firebase_auth`, `cloud_firestore`, `firebase_storage`.
    *   **Data Models (`freezed` or `equatable` recommended):**
        *   `User`: `id`, `name`, `email`, `profilePicUrl` (optional), `createdAt`.
        *   `Story`: `id`, `title`, `genre`, `length`, `content`, `createdAt`, `summary`, `userId`, `isBookmarked` (boolean).
    *   **Firestore Structure:**
        *   `users` collection: Document ID = `userId`. Fields: `name`, `email`, `profilePicUrl`, `createdAt`.
        *   `stories` collection: Document ID = `storyId`. Fields: `title`, `genre`, `length`, `content`, `createdAt`, `summary`, `userId` (indexed for user-specific queries), `isBookmarked`.
    *   **Firebase Storage:** Placeholder for potential user profile pictures or AI-generated story cover images.
    *   **Local Storage:** `hive` is preferred for caching `List<Story>` objects for offline reading of saved stories, ensuring fast access. `shared_preferences` is used for simpler key-value pairs (settings, onboarding status).
    *   **Firebase Config:** Provide clear `README.md` instructions and placeholder code for adding `google-services.json` and generating `firebase_options.dart`. **Crucially, the app must gracefully degrade if Firebase is not configured (e.g., show a local-only mode message and disable cloud features like auth/saving).**

11. **Extra features:**
    *   **Export Story to PDF:** A `PdfService` will take a `Story` object and generate a well-formatted PDF document (`pdf` package) with title, genre, author (optional), and paginated story content. The generated PDF can then be saved or shared using `printing`.
    *   **Share Story (Text/Image):**
        *   Text: Uses `share_plus` to share the story title and content as plain text.
        *   Image: Uses the `screenshot` package to capture a `RepaintBoundary` widget containing the story content (title, image/icon, body), then shares the generated image file via `share_plus`.
    *   **Mock AI History Log:** A `AiLogService` stores details of each story generation attempt (prompt, genre, length, generated title, timestamp) in `cloud_firestore` (or `hive` as a local fallback). This log is primarily for debugging or future analytics, visible only in a hidden "Developer Settings" screen or a simple `ListView` for demonstration.

12. **Accessibility & responsiveness:**
    *   **Responsive Layout:** Utilize `MediaQuery`, `Expanded`, `Flexible`, and `Wrap` widgets to create adaptive layouts that adjust gracefully across various Android screen sizes and orientations. Use appropriate padding and spacing.
    *   **Typography:** Define a `TextTheme` in `ThemeData` using `GoogleFonts` or system fonts, prioritizing readability. Ensure a clear hierarchy of text sizes (e.g., `displaySmall`, `headlineMedium`, `bodyLarge`, `labelSmall`).
    *   **Color Contrast:** Adhere to WCAG 2.1 guidelines for minimum contrast ratios for all text and interactive UI elements, ensuring readability in both light and dark themes. The primary accent color should be sufficiently distinct from backgrounds.
    *   **Semantic Labels:** Provide `semanticsLabel` for `IconButton`s and other visual-only widgets to improve accessibility for screen readers.
    *   **Scalable Text:** Ensure text scales correctly with Android's system font size settings.

13. **Tests:**
    *   **`StoryGenerationScreen` Widget Test:**
        *   Verify initial UI state (inputs visible, generated story section hidden).
        *   Test input validation (e.g., "Generate" button disabled if prompt is empty).
        *   Simulate user input and verify the "Generate" button becomes enabled.
        *   Tap "Generate" button, verify loading indicator appears, then disappears, and the generated story content is displayed correctly.
        *   Test interaction with action buttons (Save, Share, Copy) by mocking their underlying service calls.
    *   **`AiService` Unit Test:**
        *   Verify `generateStory` with different inputs (genre, length) returns a `GeneratedStory` model with expected properties (non-null `id`, `title`, `content`, `summary`).
        *   Test the simulated network delay using `tester.pumpAndSettle`.
        *   Ensure the generated content length roughly corresponds to the requested length (Short/Medium/Long).
        *   If seeded, verify deterministic output for consistent testing.

--- Implementation requirements / packages to include ---
Please scaffold pubspec with these packages (or latest equivalents):
- `flutter_riverpod`
- `firebase_core`, `firebase_auth`, `cloud_firestore`, `firebase_storage`
- `google_sign_in`
- `shared_preferences` (or `hive` for object caching)
- `flutter_local_notifications`
- `intl`, `flutter_localizations`
- `path_provider`
- `pdf`, `printing` (for PDF export)
- `share_plus`
- `screenshot` (for share as image)
- `flutter_svg` (for vector assets like logo)
- `go_router` (for declarative routing)
- `freezed` / `json_serializable` (for immutable data models)
- `dots_indicator` (for onboarding `PageView` progress)
- `google_fonts` (for enhanced typography)
- `package_info_plus` (for app version)
- `url_launcher` (for contact email link)

--- AI integration (mock) ---
Create a service `lib/services/ai_service.dart` with:
- Function `Future<GeneratedStory> generateStory({required String prompt, required String genre, required String length})`
- Implementation: Simulate a network delay (1.5–3s) using `Future.delayed`. Then, return a `GeneratedStory` model (`freezed` class recommended for immutability and ease of serialization):
  ```dart
  // Example GeneratedStory model structure
  @freezed
  class GeneratedStory with _$GeneratedStory {
    const factory GeneratedStory({
      required String id,
      required String title,
      required String genre,
      required String length,
      required String content,
      required DateTime createdAt,
      required String summary,
      @Default(false) bool isBookmarked, // For local state in UI
    }) = _GeneratedStory;

    factory GeneratedStory.fromJson(Map<String, dynamic> json) => _$GeneratedStoryFromJson(json);
  }
  ```
- Make the mock deterministic for testing by using a seeded random generator (e.g., `Random(seed)`) to ensure repeatable outputs during tests. The content length should vary based on the `length` parameter. The `title` should be derived from the prompt. This service should be easy to swap with a real API call later.

--- Code quality & documentation ---
- Provide clear, concise inline comments for each major file, class, method, and complex logic block, explaining its purpose and functionality.
- `README.md` with comprehensive documentation:
  - Project overview and key features.
  - Setup instructions: `flutter pub get`, Android setup, detailed Firebase configuration (placeholder instructions for `google-services.json` and `firebase_options.dart`).
  - How to run the app on an Android emulator/device.
  - Project structure breakdown.
  - State management (`Riverpod`) flow explanation.
  - Instructions on how to swap the mock AI service with a real API endpoint.
  - Details on the local-only fallback mode if Firebase isn't configured.
- Include an `analysis_options.yaml` enabling strict lint rules (e.g., `flutter_lints` or `pedantic`) for consistent code style and quality.
- Ensure `dart format` is used for consistent code formatting.

--- Assets & icons ---
- Generate adaptive app icons for Android (`mipmap` densities) and place them in `android/app/src/main/res/`.
- Include a placeholder app logo as an SVG (`assets/images/logo.svg`) or high-resolution PNG (`assets/images/logo.png`) in the `assets/images/` folder.
- Ensure the app will **not crash** if Firebase configuration is missing. Instead, it should display a prominent `SnackBar` message on launch (e.g., "Cloud features unavailable. Running in local-only mode.") and disable/hide UI elements that depend on Firebase (e.g., Google Sign-In button, Firestore story saving).

--- Localization ---
- Provide full i18n support for English (`en`) and Arabic (`ar`) using `.arb` files and `flutter_gen`.
- Implement robust RTL (Right-to-Left) layout support for Arabic, ensuring all UI elements (text direction, icon placement, `Row`/`AppBar` layouts) correctly mirror when the Arabic language is selected.
- Utilize `Intl.defaultLocale` and `localeResolutionCallbacks` in `MaterialApp` to correctly apply localization.

--- Output expected from generator ---
1.  Full project tree (zipped) or individual files with code content.
2.  `main.dart` that wires Riverpod, Firebase initialization (with comment placeholders), `go_router` setup, `ThemeData` provider, and `AppLocalizations`.
3.  All screen files: `SplashScreen`, `OnboardingScreen`, `AuthScreen` (with `LoginTab`, `SignUpTab`, `ForgotPasswordScreen`), `HomeScreen`, `StoryGenerationScreen`, `StoryDetailsScreen`, `SavedStoriesScreen`, `SettingsScreen`.
4.  Services: `ai_service.dart`, `auth_service.dart`, `story_service.dart` (for Firestore), `notification_service.dart`, `pdf_service.dart`, `share_service.dart`.
5.  Provider files for state management (`auth_provider.dart`, `story_provider.dart`, `settings_provider.dart`, etc.).
6.  `README.md` with detailed setup steps and architectural overview.

--- Final note to the generator ---
Generate code that is production-quality and compile-ready (aside from inserting actual Firebase credentials). Keep everything modular, testable, and provide clear comments where the developer must add real API keys or files. Use modern UI patterns, `go_router` for navigation, and smooth animations (e.g., `Hero` for shared elements, implicit animations for UI changes). Ensure basic navigation flows are fully functional with the mock AI and Firebase fallback. Define a consistent `ThemeData` with `ColorScheme`, `TextTheme`, and component themes for a cohesive visual experience.

## Features

- Modern Material 3 Design with Dark/Light theme
- Backend Integration
- Responsive Layout
- State Management with Riverpod
- Flutter Best Practices

## Getting Started

1. Install Flutter SDK
2. Run flutter pub get
3. Configure your backend
4. Run flutter run

## Generated with Genius App Builder

This Flutter application was generated using AI-powered code generation.
